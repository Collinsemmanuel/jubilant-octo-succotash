# Microservice

This is a FastAPI-based microservice.